Bäckerei Example - logo mark "Furrows" (variation 3)
====================================================

A half-round loaf rising over three field rows. The rows get shorter
towards the bottom, like furrows running away from you: a nod to the
flour's origin. Flat vector shapes only: no gradients, no shadows, no
photos, and no fonts (there is no text in the file).

FILES
-----
baeckerei-mark-3-furrows.svg
    The colour version. Loaf in brand colour #b4531a, the three rows in
    a darker brown #6b2c0b. Transparent background; made to sit on the
    brand cream #fff8ee.

baeckerei-mark-3-furrows-mono.svg
    The one-colour version. All four shapes in #b4531a, nothing else.
    The loaf and the rows stay apart through small gaps, so it reads
    without the second brown. Use it for stamps, one-colour print,
    embossing, and anywhere the two-tone version is not possible.

BOTH FILES
----------
- Square artboard, viewBox 0 0 64 64 (scales to any size).
- Plain SVG with fill attributes only, no <style>, no scripts, no
  embedded images, so it opens in browsers, Figma, Illustrator,
  Inkscape and the like.
- Contains the mark only; there is no wordmark or business name.

COLOURS
-------
Brand        #b4531a
Dark brown   #6b2c0b (colour version only)
Cream        #fff8ee (page background; not part of the files)

CHANGING THE COLOUR
-------------------
Open the file in a text editor and change the fill="#b4531a" values.
In the one-colour file, one colour value change recolours the whole mark.

SITE USE (notes)
----------------
- Both files can be used as an image in an <img> tag, or as a
  favicon: <link rel="icon" type="image/svg+xml" href="baeckerei-mark-3-furrows.svg">
- Some older browsers and some platforms still want a PNG or ICO
  favicon; export one from the SVG if you need it.
